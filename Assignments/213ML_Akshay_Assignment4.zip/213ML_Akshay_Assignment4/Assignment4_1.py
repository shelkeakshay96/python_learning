def main():
    no = int(input('Enter a number : '))
    power = lambda i: 2 ** i
    print(power(no))

if (__name__ == '__main__'):
    main()